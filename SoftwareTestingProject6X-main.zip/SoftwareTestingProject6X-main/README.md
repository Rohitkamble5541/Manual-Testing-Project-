# SoftwareTestingProject6X

Project #1 -  Testcase and Test Plan for App.vwo.com

1. Test Plan
2. Testcases

https://drive.google.com/drive/folders/11eAx342NHP1NGiqD_yQMAqfkZkbIjzNR?usp=sharing

https://sdet.live/project2

![Screenshot 2024-04-04 at 8 18 55 AM](https://github.com/PramodDutta/SoftwareTestingProject6X/assets/1409610/8f9999e6-179e-47ff-97fc-cee0e84cc501)


## Project List

| Project Name | Description | Tools Used |
|--------------|-------------|------------|
| Project 1    | Tested a web application for functionality and usability. | Test Plan, Testcases |
